To install this easy setup for FFmpeg binary, X264 presets and Yamdi the only thing you need to do it's execute the install.sh file on the terminal by typing "./install.sh", that's it!

For uninstalling just type in terminal "./uninstall.sh"

This build was made by RodrigoPolo thanks to this guide:
http://hexeract.wordpress.com/2009/04/12/how-to-compile-ffmpegmplayer-for-macosx/

Presets added by RodrigoPolo, The bin it's working great it has almost all necessary libraries to do most of the needed tasks, hope you like it.

Thanks to the FFmpeg chanel on IRC, to Dark Shikari and the FFmpeg user mailing list.

Questions? Contact me:
http://www.rodrigopolo.com/contact
