sudo rm /usr/local/bin/ffmpeg
sudo rm -rf ~/.ffmpeg
sudo rm /usr/local/bin/yamdi
sudo rm /usr/local/bin/2iflv.sh
echo "FFmpeg binary uninstall done"

