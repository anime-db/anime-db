# path to bin:
dir="/usr"

if [ -d $dir ]; then 
	echo $dir" exist";
else
	sudo mkdir $dir
fi

#
dir="/usr/local"
if [ -d $dir ]; then 
	echo $dir" exist";
else
	sudo mkdir $dir
fi

#
dir="/usr/local/bin"
if [ -d $dir ]; then 
	echo $dir" exist"; 
else
	sudo mkdir $dir
fi

# copy ffmpeg
echo "Coping FFmpeg binary"
sudo cp ./bin/ffmpeg /usr/local/bin





# ffmpeg presets dir
dir=~/.ffmpeg
if [ -d $dir ]; then 
	echo $dir" exist";
else
	sudo mkdir $dir
fi

# Copy pressets
echo "Copy FFmpeg Presets"
sudo cp ./presets/* ~/.ffmpeg

# Copy Yamdi
echo "Copy Yamdi"
sudo cp ./bin/yamdi /usr/local/bin

# Copy Shell Script for FLV Muxing and Injection
echo "Copy Shell Script for FLV Muxing and Injection"
sudo cp ./Scripts/2iflv.sh /usr/local/bin

echo "Done"
