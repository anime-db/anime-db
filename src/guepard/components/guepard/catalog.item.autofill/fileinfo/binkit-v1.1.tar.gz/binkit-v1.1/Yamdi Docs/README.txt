
   yamdi - Yet Another MetaData Injector for FLV
   Version: 1.4

   yamdi stands for Yet Another MetaData Injector and is a metadata injector
   for FLV files. It adds the onMetaData event to your FLV files. yamdi should
   run under *BSD and Linux (tested with FreeBSD, MacOSX and Ubuntu) and is
   published under the BSD license (see LICENSE).

   Compile yamdi with:

   gcc yamdi.c -o yamdi -O2 -Wall


   For more information please visit the yamdi homepage at:
   http://yamdi.sourceforge.net/
