#!/bin/sh
FILE=$1
/usr/local/bin/ffmpeg -i "$FILE" -vcodec copy -acodec copy "$FILE"_tmp.flv
/usr/local/bin/yamdi -i "$FILE"_tmp.flv -o "$FILE".flv -l
rm "$FILE"_tmp.flv
